"""Core configuration module."""
